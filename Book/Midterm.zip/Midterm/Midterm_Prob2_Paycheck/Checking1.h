
/* 
 * File:   Checking1.h
 * Author: Joseph Alipranti
 *
 * Created on October 19th, 2020, 3:55 PM
 */

#ifndef CHECKING1_H
#define CHECKING1_H

#include <string>

struct Data
{
    string name;
    int hours;
    float pay;
};

#endif /* CHECKING1_H */

