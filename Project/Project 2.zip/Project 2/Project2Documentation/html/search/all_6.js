var searchData=
[
  ['g_20',['G',['../main_8cpp.html#aed99fd0296a7a13662fc7311ccf7b5d7a2fe993340f6abb2234e543cd427df70b',1,'main.cpp']]],
  ['gethit_21',['getHit',['../class_com_guess.html#a48befdc40ef68df0c74f2e6b731d6334',1,'ComGuess']]],
  ['getnums_22',['getNums',['../class_com_guess.html#a2e0ba62a22011fb9875c22193a20f651',1,'ComGuess']]],
  ['getsize_23',['getSize',['../classtop_row.html#a31e1914c769df79c368659cc8c959aad',1,'topRow']]],
  ['getsunk_24',['getSunk',['../class_com_guess.html#afbe6a4a24eea0947724c5801f7c323a4',1,'ComGuess']]]
];
