var searchData=
[
  ['settop_113',['setTop',['../classtop_row.html#aa9c4ed92f8b6c6a335a7ebabc2aead71',1,'topRow']]],
  ['ships_114',['Ships',['../class_ships.html#ad9c30548e4446b598e187dbdbac8b1f7',1,'Ships']]],
  ['sunk_115',['sunk',['../class_usr_ships.html#ad807e4472bcd995f84358c15c59c39b0',1,'UsrShips::sunk()'],['../main_8cpp.html#ad93a258da597ca0391cc8f184399931e',1,'sunk():&#160;main.cpp']]]
];
