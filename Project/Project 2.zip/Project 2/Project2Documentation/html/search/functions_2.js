var searchData=
[
  ['gethit_90',['getHit',['../class_com_guess.html#a48befdc40ef68df0c74f2e6b731d6334',1,'ComGuess']]],
  ['getnums_91',['getNums',['../class_com_guess.html#a2e0ba62a22011fb9875c22193a20f651',1,'ComGuess']]],
  ['getsize_92',['getSize',['../classtop_row.html#a31e1914c769df79c368659cc8c959aad',1,'topRow']]],
  ['getsunk_93',['getSunk',['../class_com_guess.html#afbe6a4a24eea0947724c5801f7c323a4',1,'ComGuess']]]
];
