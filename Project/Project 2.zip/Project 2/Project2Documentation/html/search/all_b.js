var searchData=
[
  ['nearcol_37',['nearCol',['../class_com_guess.html#ad9acbab970fd9d10046bf50c11e45a3d',1,'ComGuess']]],
  ['nearrow_38',['nearRow',['../class_com_guess.html#a76b3e541009d4763556e3f83664b25bb',1,'ComGuess']]],
  ['next_39',['next',['../class_usr_ships.html#a2cf0123eeaa3e96487c9421e2bfc8202',1,'UsrShips']]]
];
