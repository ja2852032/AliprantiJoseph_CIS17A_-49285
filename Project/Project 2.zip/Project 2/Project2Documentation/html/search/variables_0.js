var searchData=
[
  ['cols_123',['COLS',['../main_8cpp.html#abfdc2552f8ab882b4380b2a56cdff54f',1,'main.cpp']]]
];
