var searchData=
[
  ['reguess_44',['reGuess',['../main_8cpp.html#a005263de868a86f57ee2ff44acaa9582',1,'main.cpp']]],
  ['rethit_45',['retHit',['../class_com_guess.html#a00ff4ddf76d1b10deb297c63788a0f70',1,'ComGuess']]],
  ['retsunk_46',['retSunk',['../class_com_guess.html#abe9cd56bd218a0c97d16f7d6c290e62a',1,'ComGuess']]],
  ['revconv_47',['revConv',['../main_8cpp.html#aec834613301366ccf1f03ad81a07fd43',1,'main.cpp']]]
];
