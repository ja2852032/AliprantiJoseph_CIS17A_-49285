var searchData=
[
  ['settop_48',['setTop',['../classtop_row.html#aa9c4ed92f8b6c6a335a7ebabc2aead71',1,'topRow']]],
  ['ships_49',['Ships',['../class_ships.html',1,'Ships'],['../class_ships.html#ad9c30548e4446b598e187dbdbac8b1f7',1,'Ships::Ships()']]],
  ['ships_2ecpp_50',['Ships.cpp',['../_ships_8cpp.html',1,'']]],
  ['ships_2eh_51',['Ships.h',['../_ships_8h.html',1,'']]],
  ['ships_2etxt_52',['ships.txt',['../ships_8txt.html',1,'']]],
  ['size_53',['size',['../class_ships.html#aba7e1af08dacbafaf11ca42b5a2d1f81',1,'Ships']]],
  ['sunk_54',['sunk',['../class_usr_ships.html#ad807e4472bcd995f84358c15c59c39b0',1,'UsrShips::sunk()'],['../main_8cpp.html#ad93a258da597ca0391cc8f184399931e',1,'sunk():&#160;main.cpp']]]
];
