/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TopRow.h
 * Author: Joseph Alipranti
 *
 * Created on October 25th, 2020, 6:20 PM
 */

#ifndef TOPROW_H
#define TOPROW_H

struct topRow
{
    char *topGrid;
    int size;
};

#endif /* TOPROW_H */

